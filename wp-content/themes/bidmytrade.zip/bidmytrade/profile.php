
<?php


get_header();


?>
<div id="main_wrapper">
	<div id="bg">
		<div id="main" class="container">
            <div id="register_my_box" class="my_box3">
            	<div class="padd10_signup">
                    <div class="box_content1">
                		<table style="width:100%;">
						    <tbody >
						    	<tr id="tab_list"  >
						         
						        <td class="active" >
						        	<a class="tab_link" data-toggle="tab" href="#sectionA">Personal details</a>
						        </td>
						        <td class="">
						        	<a class="tab_link" data-toggle="tab" href="#sectionB">Trades</a>
						        </td>
						        <td class="">
						        	<a class="tab_link" data-toggle="tab" href="#sectionC">Profile</a>
						        </td>
						        <td class="">
						        	<a class="tab_link" data-toggle="tab" href="#sectionD">Business details</a>
						        </td>
						        <td class="">
						        	<a class="tab_link" data-toggle="tab" href="#sectionE">Thank you</a>
						        </td>
						    </tr>
						    </tbody>
						</table> 
                    	<!-- <div class="row">
                    		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							    <ul id="tab_list" class="nav nav-tabs">
							        <li >
							        	<a class="active" data-toggle="tab" href="#sectionA">Personal details</a>
							        </li>
							        <li>
							        	<a data-toggle="tab" href="#sectionB">Trades</a>
							        </li>
							        <li>
							        	<a data-toggle="tab" href="#sectionC">Profile</a>
							        </li>
							        <li>
							        	<a data-toggle="tab" href="#sectionD">Business details</a>
							        </li>
							        <li>
							        	<a data-toggle="tab" href="#sectionE">Thank you</a>
							        </li>
							    </ul>
							</div>
						</div> -->
					    <div class="tab-content">
					        <div id="sectionA" class="tab-pane fade in active">
					        	<form>
					        		<div class="row">
							        	<div class="tab-content_col col-xs-12 col-sm-12 col-md-12 col-lg-12">
							        		<h4>First step to winning more work</h4>
							        	</div>
							        </div>
						        	<div class="row">
							        	<div class="tab-content_col col-xs-12 col-sm-6 col-md-6 col-lg-6">
							        		<p><label>First Name<label></p>
							        		<p><input type="text" name="first_name" value=""></p>
							        	</div>
							        	<div class="tab-content_col col-xs-12 col-sm-6 col-md-6 col-lg-6">
							        		<p><label>Last Name<label></p>
							        		<p><input type="text" name="last_name" value=""></p>
							        	</div>
						        	</div>
						        	<div class="row">
							        	<div class="tab-content_col col-xs-12 col-sm-6 col-md-6 col-lg-6">
							        		<p><p><label>Trading Name<label></p>
							        		<p><input type="text" name="trading_name" value=""></p>
							        	</div>
							        	<div class="tab-content_col col-xs-12 col-sm-6 col-md-6 col-lg-6">
							        		<p><label>Email<label></p>
							        		<p><input type="email" name="email" value=""></p>
							        	</div>
						        	</div>
						        	<div class="row">
							        	<div class="tab-content_col  col-xs-12 col-sm-6 col-md-6 col-lg-6">
							        		<p><label>Postal Code<label></p>
							        		<p><input type="text" name="postal_code" value=""></p>
							        	</div>
							        	<div class="tab-content_col col-xs-12 col-sm-6 col-md-6 col-lg-6">
							        		
							        	</div>
						        	</div>
						        	<div class="row">
							        	<div class="tab-content_col  col-xs-12 col-sm-6 col-md-6 col-lg-6">
							        		<input id="personal_details_checkbox" type="checkbox" name="postal_code" value=""> <span> I'd like monthly newsletter</span>
							        	</div>
							        	<div class="tab-content_col col-xs-12 col-sm-6 col-md-6 col-lg-6">
							        		
							        	</div>
						        	</div>
						        	<div class="row">
							        	<div id="personal_details_submit_col" class="tab-content_col  col-xs-12 col-sm-12 col-md-12 col-lg-12">
							        			<a href="#sectionB" id="personal_details_submit" data-toggle="tab" aria-expanded="false">SAVE AND CONTINUE</a>
							           	</div>
							        </div>
						            
					        	</form>
					        </div>
					        <div id="sectionB" class="tab-pane fade">
					            <form>
					        		<div class="row">
							        	<div class="tab-content_col col-xs-12 col-sm-12 col-md-12 col-lg-12">
							        		<h4>Solid leads tailored to your trades</h4>
							        	</div>
							        </div>
						        	<div id="traiding_radio_btns" class="row">
							        	<div class="tab-content_col col-xs-12 col-sm-4 col-md-4 col-lg-4">
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        	</div>
							        	<div class="tab-content_col col-xs-12 col-sm-4 col-md-4 col-lg-4">
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        	</div>
							        	<div class="tab-content_col col-xs-12 col-sm-4 col-md-4 col-lg-4">
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        		<input type="radio" name="" value="">Architectural services<br>
							        	</div>
							        </div>
						        	<div class="row">
							        	<div id="personal_details_submit_col" class="tab-content_col  col-xs-12 col-sm-12 col-md-12 col-lg-12">
							        			<a href="#sectionB" id="personal_details_submit" data-toggle="tab" aria-expanded="false">SAVE AND CONTINUE</a>
							           	</div>
							        </div>
						            
					        	</form>
					        </div>
					        <div id="sectionC" class="tab-pane fade">
					            <p>Dropdown C content…</p>
					        </div>
					        <div id="sectionD" class="tab-pane fade">
					            <p>Dropdown D content…</p>
					        </div>
					        <div id="sectionE" class="tab-pane fade">
					            <p>Dropdown E content…</p>
					        </div>
					    </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php

get_footer();