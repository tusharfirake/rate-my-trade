jQuery(document).ready(function(){

	// apply active class to selected td
    jQuery(document).on('click', '.tab_link',function(e)
    {
    	

    	
    	jQuery(this).parent().parent().find("td").removeClass("active");
    	jQuery(this).parent().parent().find("td").addClass("inactive");
    	jQuery(this).parent().removeClass("inactive");
    	jQuery(this).parent().addClass("active");
    	jQuery(".tab-content div").removeClass("in active");
    	var id =jQuery(this).attr("href");
    	jQuery(id).addClass("in active");
    	e.preventDefault();

    });

});